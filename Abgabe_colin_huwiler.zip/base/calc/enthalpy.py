from base.calc.calc_base import CalcBase
from thermocalc.funkt_Luftstoffw import L_h_x, L_h_phi, L_h_t, L_x_t
from thermocalc.converter import y_convert, h_convert


class Enthalpy(CalcBase):
    TYPE = "enthalpy"

    def create_line_steps(self, line_settings: dict) -> dict:
        calculation_settings = line_settings["calculation"]
        step = calculation_settings["step"]
        offset = calculation_settings["offset"]

        lines = self.create_range(self.min_h, self.max_h, step, offset)
        return lines

    def calculate_single_line(self, line: int, line_settings: dict):
        h_list = []
        x_list = []

        overflow = line_settings["overflow"]
        h_list_overflow = []
        x_list_overflow = []

        # check where to start
        max_h_at_min_x = L_x_t(self.min_x/1000, self.max_t, self.air_pressure)[0]
        if line < max_h_at_min_x:
            hs, xs, t = L_h_x(line, self.min_x/1000, self.air_pressure)[0:3]
        else:
            hs, xs, t = L_h_t(line, self.max_t, self.air_pressure)[0:3]

        # check where to stop
        he, xe, te = L_h_phi(line, 1, self.air_pressure)[0:3]
        if xe > self.max_x / 1000:
            he, xe = L_h_x(line, self.max_x / 1000, self.air_pressure)[0:2]
        elif te <= self.min_t:
            he, xe = L_h_t(line, self.min_t, self.air_pressure)[0:2]

        h_list.append(hs)
        x_list.append(xs)
        h_list.append(he)
        x_list.append(xe)

        # calculate overflow
        ho, xo, to = L_h_x(line, xe + overflow / 1000, self.air_pressure)[0:3]
        if xo < self.max_x / 1000 and to > self.min_t:
            h_list_overflow.append(he)
            x_list_overflow.append(xe)
            h_list_overflow.append(ho)
            x_list_overflow.append(xo)

        return ({"h": h_list, "x": x_list},
                {"h": h_list_overflow, "x": x_list_overflow})


if __name__ == '__main__':
    from pprint import pprint
    test = Enthalpy()
    pprint(test.values)
