from settings import Settings
from thermocalc.funkt_Luftstoffw import L_x_t
from thermocalc.converter import h_convert

SETTINGS_PATH = "settings.json"


class CalcBase(object):
    TYPE = "enthalpy"

    def __init__(self, height_over_sea: int = 600):
        self._load_settings()  # load settings and store as attribute
        self.set_height_over_sea(height_over_sea)  # set air pressure
        self.values = {"value_lines": {}, "overflow_lines": {}}  # empty dict to store calculated values
        self._set_boundaries()  # load settings as attribute for easy access
        self.calculate_values()  # calculate line values

    def set_height_over_sea(self, height_over_sea):
        self.air_pressure = 101325 * (1 - 6.5 * height_over_sea / 288150) ** 5.255

    def _load_settings(self):
        # Gets Global Settings:
        self.settings_global = Settings().settings

        # Gets Settings for the specific line type
        self.settings_type = Settings().get("lines").get(self.TYPE)

    def _set_boundaries(self):
        # load settings in variable for easy access, is initalized with init
        self.min_t = self.settings_global["calc_range"]["t"][0]
        self.max_t = self.settings_global["calc_range"]["t"][-1]
        self.min_x = self.settings_global["calc_range"]["x"][0]
        self.max_x = self.settings_global["calc_range"]["x"][-1]
        self.min_h = L_x_t(self.min_x/1000, self.min_t, self.air_pressure)[0]
        self.max_h = L_x_t(self.max_x/1000, self.max_t, self.air_pressure)[0]
        self.max_h_at_min_x = L_x_t(self.min_x/1000, self.max_t, self.air_pressure)[0]
        self.min_y = h_convert([self.min_h], [self.min_x/1000])[0]
        self.max_y = h_convert([self.max_h_at_min_x], [self.min_x/1000])[0]

    def calculate_values(self):
        # generate Line Values sorted by line type
        for line_type in self.settings_type:
            # get settings dictionary of line type
            line_settings = self.settings_type[line_type]

            # get lines to calculate
            lines_to_calculate = self.create_line_steps(line_settings)

            # calculate values and add to dictionary
            value_lines, overflow_lines \
                = self.calculate_lines_of_type(lines_to_calculate, line_settings)
            self.values["value_lines"][line_type] = value_lines
            self.values["overflow_lines"][line_type] = overflow_lines

    def create_line_steps(self, calculation_settings: dict):
        # this function is a placeholder, returns list or range with lines to calculate
        lines = []

        return lines

    def calculate_lines_of_type(self, lines, line_settings: dict):
        lines_line_type = {}
        lines_overflow = {}
        for line in lines:
            values_line, values_overflow = self.calculate_single_line(line, line_settings)
            lines_line_type[str(line)] = values_line
            lines_overflow[str(line)] = values_overflow
        return lines_line_type, lines_overflow

    @staticmethod
    def calculate_single_line(line: int, line_settings):
        # placeholder, function is properly defined in child classes
        h_list = []
        x_list = []
        h_list_overflow = []
        x_list_overflow = []

        return {"h": h_list, "x": x_list}, {"h": h_list_overflow, "x": x_list_overflow}

    def create_range(self, start, stop, step, offset):
        # adjust the start to the offset of "step"
        if start % step != offset:
            start = (start // step + 1) * step

        return self.step_generator(start, stop, step)

    @staticmethod
    def step_generator(start, stop, step):
        step_count = int((stop - start) / step + 1)
        for i in range(step_count):
            yield start + i * step


if __name__ == '__main__':
    test = CalcBase()
    print(test.settings_global)
    print(test.settings_type)

