from base.calc.calc_base import CalcBase
from thermocalc.funkt_Luftstoffw import L_t_phi, L_x_phi, L_x_t


class Comfort(CalcBase):
    TYPE = "comfort"

    def calculate_values(self):
        # generate Line Values sorted by line type
        for line_type in self.settings_type:
            # get settings dictionary of line type
            line_settings = self.settings_type[line_type]

            # calculate values and add to dictionary
            value_lines, overflow_lines \
                = self.calculate_lines_of_type(line_settings)
            self.values["value_lines"][line_type] = value_lines
            self.values["overflow_lines"][line_type] = overflow_lines

    def calculate_lines_of_type(self, line_settings: dict):
        lines_line_type = {}
        lines_overflow = {}

        values_line, values_overflow = self.calculate_single_line(line_settings)
        lines_line_type[0] = values_line
        lines_overflow[0] = values_overflow

        return lines_line_type, lines_overflow

    def calculate_single_line(self, line_settings: dict):
        h_list = []
        x_list = []

        min_t = line_settings["calculation"]["min_t"]
        max_t = line_settings["calculation"]["max_t"]
        min_x = line_settings["calculation"]["min_x"]
        max_x = line_settings["calculation"]["max_x"]
        min_phi = line_settings["calculation"]["min_phi"]
        max_phi = line_settings["calculation"]["max_phi"]

        # bottom left
        h0, x0 = L_t_phi(min_t, min_phi/100, self.air_pressure)[0:2]
        if x0 < min_x/1000:
            h0, x0 = L_x_t(min_x/1000, min_t, self.air_pressure)[0:2]

        h_list.append(h0)
        x_list.append(x0)

        # bottom right
        h1, x1 = L_t_phi(min_t, max_phi / 100, self.air_pressure)[0:2]
        if x1 > max_x/1000:
            h1, x1 = L_x_t(max_x/1000, min_t, self.air_pressure)[0:2]

        h_list.append(h1)
        x_list.append(x1)

        # bottom to top right
        h3, x3 = L_t_phi(max_t, max_phi / 100, self.air_pressure)[0:2]
        if x3 > max_x/1000:
            h3, x3 = L_x_t(max_x/1000, max_t, self.air_pressure)[0:2]

        if x1 != x3:
            spacing = x3 - x1
            for i in range(11):
                x2 = x1 + spacing / 10 * i
                h2, x2 = L_x_phi(x2, max_phi / 100, self.air_pressure)[0:2]
                h_list.append(h2)
                x_list.append(x2)

        # top right
        h_list.append(h3)
        x_list.append(x3)

        # top left
        h4, x4 = L_t_phi(max_t, min_phi / 100, self.air_pressure)[0:2]
        if x4 < min_x / 1000:
            h4, x4 = L_x_t(min_x / 1000, min_t, self.air_pressure)[0:2]

        h_list.append(h4)
        x_list.append(x4)

        # top to bottom left
        h6, x6 = L_t_phi(min_t, min_phi / 100, self.air_pressure)[0:2]
        if x6 < min_x / 1000:
            h6, x6 = L_x_t(min_x / 1000, min_t, self.air_pressure)[0:2]

        if x4 != x6:
            spacing = x6 - x4
            for i in range(11):
                x5 = x4 + spacing / 10 * i
                h5, x5 = L_x_phi(x5, min_phi / 100, self.air_pressure)[0:2]
                h_list.append(h5)
                x_list.append(x5)

        h_list.append(h6)
        x_list.append(x6)

        h_list_overflow = []
        x_list_overflow = []

        print("test")

        return ({"h": h_list, "x": x_list},
                {"h": h_list_overflow, "x": x_list_overflow})
