from base.description.label_base import LabelBase


class LabelEnthalpy(LabelBase):
    TYPE = "enthalpy"

    def _create_label(self, fig_line, value):
        # check if overflow line has a value
        if not fig_line["x"]:
            return

        # get coordinates of the endpoint of the overflow line
        x = fig_line["x"][-1]
        y = fig_line["y"][-1]

        # check if position is in plot range
        if not self.check_bounds(x+0.5, y-2, "calc"):
            return

        # round and format value
        value = round(float(value), self.rounding)
        value = f"{value:.{self.rounding}f}"

        self.annotations.append(dict(x=x,
                                     y=y,
                                     text=f"{self.offset * " "}{value}",
                                     showarrow=False,
                                     font=self.font,
                                     xanchor="center",
                                     **self.arguments))
