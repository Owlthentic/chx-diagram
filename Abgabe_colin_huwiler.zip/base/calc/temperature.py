from base.calc.calc_base import CalcBase
from thermocalc.funkt_Luftstoffw import L_h_t, L_t_phi, L_x_t


class Temperature(CalcBase):
    TYPE = "temperature"

    def create_line_steps(self, line_settings: dict) -> dict:
        calculation_settings = line_settings["calculation"]
        step = calculation_settings["step"]
        offset = calculation_settings["offset"]

        lines = self.create_range(self.min_t, self.max_t, step, offset)
        return lines

    def calculate_single_line(self, line: int, line_settings: dict):
        h_list_line = []
        x_list_line = []

        overflow = line_settings["overflow"]
        h_list_overflow = []
        x_list_overflow = []

        # check where to start
        hs, xs = L_x_t(self.min_x/1000, line, self.air_pressure)[0:2]
        h_list_line.append(hs)
        x_list_line.append(xs)

        # check where to stop
        he, xe = L_t_phi(line, 1, self.air_pressure)[0:2]
        if xe > self.max_x/1000:
            he, xe = L_x_t(self.max_x/1000, line, self.air_pressure)[0:2]

        h_list_line.append(he)
        x_list_line.append(xe)

        # calculate overflow
        h_list_overflow.append(hs)
        x_list_overflow.append(xs)
        ho, xo = L_x_t((self.min_x-overflow)/1000, line, self.air_pressure)[0:2]
        h_list_overflow.append(ho)
        x_list_overflow.append(xo)

        return ({"h": h_list_line, "x": x_list_line},
                {"h": h_list_overflow, "x": x_list_overflow})


if __name__ == '__main__':
    from pprint import pprint
    test = Temperature()
    pprint(test.values)
