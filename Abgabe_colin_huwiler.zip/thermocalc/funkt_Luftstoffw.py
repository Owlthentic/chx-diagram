import math

# Konstanten definieren
R_L = 287.1     # Gaskonstante Luft [J/kgK]
R_D = 461.4     # Gaskonstante Dampf [J/kgK]

T_0 = 273.15    # Absoluter Nullpunkt [K]
r_W = 2501      # Verdampfungswärme von Wasser bei 0° [kJ/kg]

c_W = 4.18      # spez. Wärmekap. Wasser [kJ/kgK]
c_D = 1.86      # spez. Wärmekap. Wasserdampf [kJ/kgK]
c_L = 1.006     # spez. Wärmekap. Luft [kJ/kgK]


def L_t_phi(t, phi, p=96600):
    """
    Eingabe:
        t:      Temperatur [°C]
        phi:    relative Feuchtigkeit [-] (0..1)
        p:      Luftdruck [Pa]

    Ausgabe:
        h:      Enthalpie [kJ/kg]
        x:      absolute Feuchtigkeit [kg/kg]
        t:      Temperatur [°C]
        phi:    relative Feuchtigkeit [-] (0..1)
        rho:    Dichte [kg/m3]
        ps:     Sättigungsdruck [Pa]
    """

    x   = L_x(phi, L_ps(t), p)

    h   = L_cp(t) * t + x * (r_W + c_D * t)
    x   = x
    t   = t
    phi = phi
    rho = L_rho(x, t, p)
    ps  = L_ps(t)

    return(h, x, t, phi, rho, ps)


def L_x_phi(x, phi, p=96600):
    """
    Eingabe:
        x:      absolute Feuchtigkeit [kg/kg] 
        phi:    relative Feuchtigkeit [-] (0..1)
        p:      Luftdruck [Pa]

    Ausgabe:
        h:      Enthalpie [kJ/kg]
        x:      absolute Feuchtigkeit [kg/kg]
        t:      Temperatur [°C]
        phi:    relative Feuchtigkeit [-] (0..1)
        rho:    Dichte [kg/m3]
        ps:     Sättigungsdruck [Pa]
    """

    t   = L_t(x * R_D * p / (phi * (R_L + x * R_D)))

    h   = L_cp(t) * t + x * (r_W + c_D * t)
    x   = x
    t   = t
    phi = phi
    rho = L_rho(x, t, p)
    ps  = L_ps(t)

    return(h, x, t, phi, rho, ps)


def L_x_t(x, t, p=96600):
    """
    Eingabe:
        x:      absolute Feuchtigkeit [kg/kg] 
        t:      Temperatur [°C]
        p:      Luftdruck [Pa]

    Ausgabe:
        h:      Enthalpie [kJ/kg]
        x:      absolute Feuchtigkeit [kg/kg]
        t:      Temperatur [°C]
        phi:    relative Feuchtigkeit [-] (0..1)
        rho:    Dichte [kg/m3]
        ps:     Sättigungsdruck [Pa]
    """

    h   = L_cp(t) * t + x * (r_W + c_D * t)
    x   = x
    t   = t
    phi = L_phi(x, L_ps(t), p)
    rho = L_rho(x, t, p)
    ps  = L_ps(t)

    return(h, x, t, phi, rho, ps)


def L_h_phi(h, phi, p= 96600):
    """
    Eingabe:
        h:      Wärmekapazität [kJ/kg]  
        phi:    relative Feuchtigkeit [-] (0..1)  
        p:      Luftdruck [Pa]

    Ausgabe:
        h:      Enthalpie [kJ/kg]
        x:      absolute Feuchtigkeit [kg/kg]
        t:      Temperatur [°C]
        phi:    relative Feuchtigkeit [-] (0..1)
        rho:    Dichte [kg/m3]
        ps:     Sättigungsdruck [Pa]
    """

    t_o = 100
    t_u = -20
    t_m = (t_o + t_u) / 2
    h_m = L_cp(t_m) * t_m + L_x(phi, L_ps(t_m), p) * (r_W + c_D * t_m)

    while abs(h - h_m) > 0.01:
        t_m = (t_o + t_u) / 2
        h_m = L_cp(t_m) * t_m + L_x(phi, L_ps(t_m), p) * (r_W + c_D * t_m)

        if h < h_m:
            t_o = t_m
        else:
            t_u = t_m
        if abs(t_o - t_u) < 0.000000000000001:
            break

    x = L_x(phi, L_ps(t_m), p)

    h   = h
    x   = x
    t   = t_m
    phi = phi
    rho = L_rho(x, t_m, p)
    ps  = L_ps(t_m)

    return(h, x, t, phi, rho, ps)


def L_h_t(h, t, p=96600):
    """
    Eingabe:
        h:      Wärmekapazität [kJ/kg]  
        t:      Temperatur [°C]  
        p:      Luftdruck [Pa]

    Ausgabe:
        h:      Enthalpie [kJ/kg]
        x:      absolute Feuchtigkeit [kg/kg]
        t:      Temperatur [°C]
        phi:    relative Feuchtigkeit [-] (0..1)
        rho:    Dichte [kg/m3]
        ps:     Sättigungsdruck [Pa]
    """

    x_o = 5
    x_u = 0
    x_m = (x_o + x_u) / 2
    h_m = L_cp(t) * t + x_m * (r_W + c_D * t)

    while abs(h - h_m) > 0.01:
        x_m = (x_o + x_u) / 2
        h_m = L_cp(t) * t + x_m * (r_W + c_D * t)

        if h < h_m:
            x_o = x_m
        else:
            x_u = x_m

        if (x_o - x_u) < 0.000000000000001:
            break
    
    h   = h
    x   = x_m
    t   = t
    phi = L_phi(x_m, L_ps(t), p)
    rho = L_rho(x_m, t, p)
    ps  = L_ps(t)

    return(h, x, t, phi, rho, ps)

        
def L_h_x(h, x, p=96600):
    """
    Eingabe:
        h:      Wärmekapazität [kJ/kg]  
        x:      absolute Feuchtigkeit [kg/kg]  
        p:      Luftdruck [Pa]

    Ausgabe:
        h:      Enthalpie [kJ/kg]
        x:      absolute Feuchtigkeit [kg/kg]
        t:      Temperatur [°C]
        phi:    relative Feuchtigkeit [-] (0..1)
        rho:    Dichte [kg/m3]
        ps:     Sättigungsdruck [Pa]
    """

    t_m = (h - x * r_W) / (c_L + c_D * x)

    h   = h
    x   = x
    t   = t_m
    phi = L_phi(x, L_ps(t_m), p)
    rho = L_rho(x, t_m, p)
    ps  = L_ps(t_m)

    return(h, x, t, phi, rho, ps)


def L_phi(x, ps, p=96600):
    """
    Eingabe: 
        x:      absolute Feuchtigkeit [kg/kg]  
        ps:     Sättigungsdruck [Pa]
        p:      Luftdruck [Pa]

    Ausgabe:
        phi:    relative Feuchtigkeit [-] (0..1)
    """

    L_phi = x * R_D * p / (ps * (R_L + x * R_D))

    return(L_phi)


def L_ps(t):
    """
    Eingabe:
        t:      Temperatur [°C]  

    Ausgabe:
        ps:     Sättigungsdruck [Pa]
    """

    if t < 0:
        L_ps = 611 * math.exp(-4.909965 * 10 ** -4 + 8.183197 * 10 ** -2 * t - 5.552967 * 10 ** -4 * t ** 2 - 2.228376 * 10 ** -5 * t ** 3 - 6.211808 * 10 ** -7 * t ** 4)

    elif t < 100:
        L_ps = 611 * math.exp(-1.91275 * 10 ** -4 + 7.258 * 10 ** -2 * t - 2.939 * 10 ** -4 * t ** 2 + 9.841 * 10 ** -7 * t ** 3 - 1.92 * 10 ** -9 * t ** 4)

    elif t >= 100:
        L_ps = 611 * math.exp(6 * 10 ** -5 + 7.13274 * 10 ** -2 * t - 2.581631 * 10 ** -4 * t ** 2 + 6.311955 * 10 ** -7 * t ** 3 - 7.167112 * 10 ** -10 * t ** 4)

    return(L_ps)


def L_rho(x, t, p=96600):
    """
    Eingabe:
        x:      absolute Feuchtigkeit [kg/kg] 
        t:      Temperatur [°C]  
        p:      Luftdruck [Pa]

    Ausgabe:
        rho:    Dichte [kg/m3]
    """

    L_rho = (1 + x) * p / ((R_L + x * R_D) * (t + T_0))

    return(L_rho)


def L_t(ps):
    """
    Eingabe:
        ps:     Sättigungsdruck [Pa]

    Ausgabe:
        t:      Temperatur [°C]
    """

    t_o = 100
    t_u = -200
    t_m = (t_o + t_u) / 2
    p_m = L_ps(t_m)

    while abs(ps - p_m) > 0.1:
        t_m = (t_o + t_u) / 2
        p_m = L_ps(t_m)

        if ps < p_m:
            t_o = t_m
        else:
            t_u = t_m

        if abs(t_o - t_u) < 0.000000000000001:
            break
    
    L_t = t_m

    return(L_t)


def L_x(phi, ps, p=96600):
    """
    Eingabe:
        phi:    phi relative Feuchtigkeit [-] (0..1)   
        ps:     ps  Sättigungsdruck [Pa]   
        p:      Luftdruck [Pa]

    Ausgabe:
        x:      absolute Feuchtigkeit [kg/kg]
    """

    L_x = (phi * ps * R_L) / ((p - phi * ps) * R_D)

    return(L_x)


def L_cp(t):
    """
    Eingabe:
        t:      Temperatur [°C]  

    Ausgabe:
        cp:     spez. Wärmekapazit�t [kJ/kgK]
    """

    L_cp = 1.006256 + 2.120536 * 10 ** -5 * t + 4.180195 * 10 ** -7 * t ** 2 - 1.521916 * 10 ** -10 * t ** 3

    return(L_cp)


def L_p(hoehe):
    """
    Eingabe:
        hoehe:  Höhe [m.ü.M.] 

    Ausgabe:
        p:      Luftdruck in der Höhe hoehe [Pa] 
    """

    L_p = 101325 * 2.71828 ** -(hoehe / 7990)

    return(L_p)


def L_tf(t, x, p=100000):
    """
    Eingabe:
        t:      Temperatur [°C]  
        x:      absolute Feuchtigkeit [kg/kg]  
        p:      Luftdruck [Pa]

    Ausgabe:
        tf:     Feuchtkugeltemperatur [°C]
    """

    tp = L_t(L_phi(x, L_ps(t), p) * L_ps(t))
    hs = 0
    hf = 0
    h  = L_cp(t) * t + x * (r_W + c_D * t)
    tf = round(tp - 2)

    while hs < hf:
        tf = tf + 1
        hsr = hs
        hfr = hf
        xs = (R_L / R_D) * L_ps(tf) / (p - L_ps(tf))
        hs = L_cp(tf) * tf + xs * (r_W + c_D * tf)
        hf = h + (xs - x) * c_W * tf

    K = (hfr - hsr) / (hs - hf)
    L_tf = (tf * (K + 1) - 1) / (1 + K)

    return(L_tf)


def L_eta(t):
    """
    Eingabe:
        t:      Temperatur [°C]  

    Ausgabe:
        eta:    Dynamische Viskosität [Pa*s]
    """

    L_eta = (1.72436 * 10 ** (-5) + 5.04587 * 10 ** (-8) * t - 3.923361 * 10 ** (-11) * t ** 2 + 4.046118 * 10 ** (-14) * t ** 3)

    return(L_eta)


def L_xs(t, p):
    """
    Eingabe:
        t:      Temperatur [°C]   
        p:      Luftdruck [Pa]

    Ausgabe:
        xs:     Wassergehalt [kg/kg]
    """

    L_xs = 0.6222 * L_ps(t) / (p - L_ps(t))

    return(L_xs)


def L_x_tf(t, tf, p=100000):
    """
    Eingabe:
        t:      Temperatur [°C] 
        tf:     Feuchtkugeltemperatur [°C] 
        p:      Luftdruck [Pa]

    Ausgabe:
        x:      absolute Feuchtigkeit [kg/kg]
    """

    xf = L_xs(tf, p)

    L_x_tf = (xf * (2501 + tf * (1.86 - 4.19)) - 1.01 * (t - tf)) / (2501 + 1.86 * t - 4.19 * tf)

    return(L_x_tf)

