from base.description.label_base import LabelBase


class LabelRelHumidity(LabelBase):
    TYPE = "rel_humidity"

    def _create_label(self, fig_line, value):
        # check if overflow line has a value
        if not fig_line["x"]:
            return

        # get coordinates of the endpoint of the overflow line
        x = fig_line["x"][-1]
        y = fig_line["y"][-1]

        if x < self.settings_global["calc_range"]["x"][-1]:
            return

        # check if position is in plot range
        if not self.check_bounds(x, y, "plot"):
            return

        # round and format value
        value = round(float(value), self.rounding)
        value = f"{value:.{self.rounding}f}"

        self.annotations.append(dict(x=x,
                                     y=y - self.offset,
                                     text=f"{value}",
                                     showarrow=False,
                                     font=self.font,
                                     xanchor="left",
                                     **self.arguments))
