from base.calc.calc_base import CalcBase
from thermocalc.funkt_Luftstoffw import L_x_t
from thermocalc.converter import h_convert


class AbsHumidity(CalcBase):
    TYPE = "abs_humidity"

    def create_line_steps(self, line_settings: dict) -> dict:
        calculation_settings = line_settings["calculation"]
        step = calculation_settings["step"]
        offset = calculation_settings["offset"]

        lines = self.create_range(self.min_x, self.max_x, step, offset)
        return lines

    def calculate_single_line(self, line: int, line_settings: dict):
        y_list_line = []
        x_list_line = []

        overflow = line_settings["overflow"]
        y_list_overflow = []
        x_list_overflow = []

        # check where to start
        ys = self.min_y
        xs = line/1000

        y_list_line.append(ys)
        x_list_line.append(xs)

        # check where to stop
        he = L_x_t(line/1000, self.max_t, self.air_pressure)[0]
        xe = line/1000
        ye = h_convert([he], [xe])[0]

        y_list_line.append(ye)
        x_list_line.append(xe)

        # calculate overflow
        yo = ys - overflow
        xo = xs

        y_list_overflow.append(ys)
        x_list_overflow.append(xs)
        y_list_overflow.append(yo)
        x_list_overflow.append(xo)

        return ({"y": y_list_line, "x": x_list_line},
                {"y": y_list_overflow, "x": x_list_overflow})


if __name__ == '__main__':
    from pprint import pprint
    test = AbsHumidity()
    pprint(test.values)
