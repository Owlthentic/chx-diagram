import plotly.graph_objs as go
import plotly.io as pio
from base.calc.calc_base import CalcBase
from base.calc.enthalpy import Enthalpy
from base.calc.temperature import Temperature
from base.calc.rel_humidity import RelHumidity
from base.calc.abs_humidity import AbsHumidity
from base.calc.comfort import Comfort
from base.description.label_temperature import LabelTemperature
from base.description.label_abs_humidity import LabelAbsHumidity
from base.description.label_rel_humidity import LabelRelHumidity
from base.description.label_enthalpy import LabelEnthalpy
from thermocalc.funkt_Luftstoffw import L_x_t
from thermocalc.converter import h_convert, x_convert
from settings import Settings

SETTINGS_PATH = "plot/settings.json"
TEMPLATE_PATH = "base/plot/templates/"
DEFAULT_TEMPLATE = "default_template"


class CHXDiagram(object):
    """
    Class representing a CHXDiagram.

    Args:
        height_over_sea: The height over sea level as an integer.

    Attributes:
        lines: A dictionary to store the index of lines of the Plotly Figure.
        fig: An instance of Plotly Figure for the diagram.
        height_over_sea: The height over sea level provided during initialization.
        settings_global: A dictionary to store the global settings dictionary.

    Methods:
        _load_settings: Private method to load global settings.
        load_template: Method to load a template for the diagram.
        fig_setup: Method to set up the layout of the figure.
        set_size: Method to set the size of the figure.
        h_adjust: Static method to adjust the provided height list.
        x_adjust: Static method to adjust the provided x list.
        gen: Method to generate lines and descriptions for the diagram.
        plot: Method to plot lines on the diagram.
        get_line_properties: Method to get line properties based on category and type.
        show: Method to display the diagram.
    """
    def __init__(self, height_over_sea):

        if not isinstance(height_over_sea, int):
            raise TypeError("height_over_sea must be of int type.")
        if height_over_sea < 0:
            raise ValueError("height_over_sea must be a positive integer.")
        self.height_over_sea = height_over_sea

        self.settings_global = Settings().settings
        self.fig = go.Figure()
        self.load_template()
        self.lines = {}
        self._update_layout()
        self.generate_diagram()

    def load_template(self, template_name: str = DEFAULT_TEMPLATE):
        """
        Function to load and apply a template for a plotly figure.

        Args:
            template_name: name of the template to load.

        Returns:
            None
        """
        template_path = f"{TEMPLATE_PATH}{template_name}.json"
        template = Settings(template_path).settings
        pio.templates[template_name] = template
        self.fig.update_layout(template=template_name)

    def _update_layout(self):
        """
        Initialize the layout of the figure based on specified global settings.

        Returns:
            None
        """
        min_t, max_t = self.settings_global["figure_settings"]["t"]
        min_x, max_x = self.settings_global["figure_settings"]["x"]
        min_y = L_x_t(min_x/1000, min_t)[0]
        max_y = L_x_t(min_x/1000, max_t)[0]

        self.fig.update_layout(
            yaxis=dict(range=[min_y, max_y]),
            xaxis=dict(range=[min_x, max_x]),
            showlegend=False)

        width = self.settings_global["figure_settings"]["width"]
        height = self.settings_global["figure_settings"]["height"]
        self.set_size(width, height)

    def set_size(self, width, height):
        self.fig.update_layout(width=width, height=height)

    def generate_diagram(self):
        """
        Generates plots from calculated values of children from CalcBase and adds labels to the plot.

        Returns:
            None
        """
        self._add_lines()
        self._add_labels()

    def _add_lines(self):
        """
            Method to plot lines.
            Returns:
                None
            """
        self._plot_lines(Temperature(self.height_over_sea), True)
        self._plot_lines(Enthalpy(self.height_over_sea), True)
        self._plot_lines(RelHumidity(self.height_over_sea), True)
        self._plot_lines(AbsHumidity(self.height_over_sea), False)
        self._plot_lines(Comfort(self.height_over_sea), True)

    def _plot_lines(self, calc_obj: CalcBase, h_to_y: bool):
        """
        Args:
            calc_obj: CalcBase object that contains calculated values for plotting
            h_to_y: Boolean flag indicating whether to convert h value to y value

        Returns:
            None
        """
        line_category = calc_obj.TYPE
        self.lines[line_category] = {}

        for section in calc_obj.values:
            self.lines[line_category][section] = {}

            for line_type in calc_obj.values[section]:
                self.lines[line_category][section][line_type] = {}

                line_properties = self._get_line_properties(line_category, section, line_type)

                for value in calc_obj.values[section][line_type]:
                    value_list = calc_obj.values[section][line_type][value]

                    x = value_list["x"]
                    if h_to_y:
                        h = value_list["h"]
                        y_adjusted = h_convert(h, x)
                    else:
                        y = value_list["y"]
                        y_adjusted = y

                    x_adjusted = x_convert(x)

                    name = f"{line_category}_{section}_{line_type}_{value}"
                    name = value

                    # create line and add to figure
                    trace = go.Scatter(
                        x=x_adjusted,
                        y=y_adjusted,
                        mode="lines",
                        name=name,
                        line=line_properties)
                    self.fig.add_trace(trace)

                    # store index
                    index = len(self.fig.data)-1
                    self.lines[line_category][section][line_type][value] = index

    def _get_line_properties(self, line_category: str, section: str, line_type: str) -> dict:
        """
        Gets settings for the given line properties.

        Args:
            line_category: Defines what category the line properties belong to. ex: enthalpy, temperature, etc.
            section: Defines if the line is overflow or default line_type.
            line_type: Defines what line_type the line properties belong to.

        return:
            line_type_dict: dictionary with settings for plotting lines.

        """
        if section == "overflow_lines":
            line_type_name = self.settings_global["lines"][line_category][line_type]["overflow_type"]
        else:
            line_type_name = self.settings_global["lines"][line_category][line_type]["line_type"]

        line_type_dict = self.settings_global["line_types"][line_type_name]

        return line_type_dict

    def _add_labels(self):
        # add description
        label_temperature = LabelTemperature(self.lines, self.fig)
        label_abs_humidity = LabelAbsHumidity(self.lines, self.fig)
        label_rel_humidity = LabelRelHumidity(self.lines, self.fig)
        label_enthalpy = LabelEnthalpy(self.lines, self.fig)
        labels = (label_temperature.annotations
                  + label_abs_humidity.annotations
                  + label_rel_humidity.annotations
                  + label_enthalpy.annotations)
        self.fig.update_layout(annotations=labels)

    def show(self):
        """
        Display the figure.

        Return:
            None
        """
        self.fig.show()


if __name__ == '__main__':
    chx_diag = CHXDiagram(int(700))

    chx_diag.show()
