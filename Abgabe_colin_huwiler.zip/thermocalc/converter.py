
GRADIANT = -2.501


def h_convert(h_list: list, x_list: list) -> list:
    """
    Converts the provided list of h[kJ/kg] values to y values for plotting.

    Args:
        h_list: list of h[kJ/kg] values.
        x_list: list of x[kg/kg] values.

    Returns:
        y_list: converted list of h[kJ/kg] values for plotting.
    """
    y_list = []
    for pos, h in enumerate(h_list):
        y = h + x_list[pos] * GRADIANT * 1000
        y_list.append(y)
    return y_list


def y_convert(y_list: list, x_list: list) -> list:
    """
    Converts the y values for plotting to h[kJ/kg] values.

    Args:
        y_list: list of y for plotting.
        x_list: list of x[kg/kg] values.
    Returns:
        h_list: list of h[kJ/kg] values.
    """
    h_list = []
    for pos, y in enumerate(y_list):
        h = y - x_list[pos] * GRADIANT * 1000
        h_list.append(h)
    return h_list


def x_convert(x_list: list) -> list:
    """
    Adjusts the provided list of x[kg/kg] values to x[g/kg] values for plotting.

    Args:
        x_list: list

    Returns:
        list: containing the adjusted values of x_list multiplied by 1000
    """
    x_list_offset = []
    for x in x_list:
        x_offset = x * 1000
        x_list_offset.append(x_offset)
    return x_list_offset
