import pandas as pd
from thermocalc.funkt_Luftstoffw import L_t_phi
from thermocalc.converter import h_convert, x_convert

df = pd.DataFrame()

df_import = pd.read_csv("Naters-hour_2005.txt", sep=";", header=2)
df["h"] = df_import.apply(lambda row: L_t_phi(row[" Ta"], row[" RH"]/100, row[" p"]*100)[0], axis=1)
df["x"] = df_import.apply(lambda row: L_t_phi(row[" Ta"], row[" RH"]/100, row[" p"]*100)[1], axis=1)

df["y"] = h_convert(df["h"], df["x"])
df["x"] = x_convert(df["x"])

from base.chx_diagram import CHXDiagram
import plotly.graph_objects as go
import plotly.express as px

# erstellt leeres Diagramm für 800 m.ü.M.
chx_diag = CHXDiagram(800)

# erstelle Kontour Linien mit Wetterdaten
chx_fig = px.density_contour(df, x="x", y="y", nbinsx=10, nbinsy=10)
for contour_level in chx_fig.data:
    contour_level.update(line=dict(width=1.5, color='darkblue'))

# erstell Diagramm mit Wetterdaten
scatter_plot = go.Figure().add_scatter(x=df["x"],
                                  y=df["y"],
                                  mode="markers",
                                  marker=dict(
                                      color="cornflowerblue",
                                      opacity=0.25,
                                      size=4))

# Wetterdaten Diagramm in den Hintergrund von CHX-Diagramm
# Layout und Beschriftung übernehmen
chx_fig.layout.update(chx_diag.fig.layout)
# Linien übernehmen
for trace in scatter_plot.data:
    chx_fig.add_trace(trace)
for trace in chx_diag.fig.data:
    chx_fig.add_trace(trace)

chx_fig.write_image('chx_diagram_countour_and_Scatter.pdf', scale = 16)
