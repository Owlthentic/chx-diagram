import pandas as pd
from thermocalc.funkt_Luftstoffw import L_t_phi
from thermocalc.converter import h_convert, x_convert

# Wetterdaten 2005
df_2005 = pd.DataFrame()

df_import = pd.read_csv("Naters-hour_2005.txt", sep=";", header=2)
df_2005["h"] = df_import.apply(lambda row: L_t_phi(row[" Ta"], row[" RH"]/100, row[" p"]*100)[0], axis=1)
df_2005["x"] = df_import.apply(lambda row: L_t_phi(row[" Ta"], row[" RH"]/100, row[" p"]*100)[1], axis=1)

df_2005["y"] = h_convert(df_2005["h"], df_2005["x"])
df_2005["x"] = x_convert(df_2005["x"])

# Wetterdaten 2050
df_2050 = pd.DataFrame()

df_import = pd.read_csv("Naters-hour_2050_RCP_8.5.txt", sep=";", header=2)
df_2050["h"] = df_import.apply(lambda row: L_t_phi(row[" Ta"], row[" RH"]/100, row[" p"]*100)[0], axis=1)
df_2050["x"] = df_import.apply(lambda row: L_t_phi(row[" Ta"], row[" RH"]/100, row[" p"]*100)[1], axis=1)

df_2050["y"] = h_convert(df_2050["h"], df_2050["x"])
df_2050["x"] = x_convert(df_2050["x"])


from base.chx_diagram import CHXDiagram
import plotly.graph_objects as go
import plotly.express as px

# erstellt leeres Diagramm für 680 m.ü.M.
chx_diag = CHXDiagram(680)

# erstelle Kontour Linien mit Wetterdaten
chx_fig = px.density_contour(df_2005, x="x", y="y", nbinsx=10)
for contour_level in chx_fig.data:
    contour_level.update(line=dict(width=1.5, color='darkblue'))

contour_2050 = px.density_contour(df_2050, x="x", y="y", nbinsx=10)
for contour_level in contour_2050.data:
    contour_level.update(line=dict(width=1.5, color='Violet'))

# Wetterdaten Diagramm in den Hintergrund von CHX-Diagramm
# Layout und Beschriftung übernehmen
chx_fig.layout.update(chx_diag.fig.layout)
# Linien übernehmen
for trace in contour_2050.data:
    chx_fig.add_trace(trace)
for trace in chx_diag.fig.data:
    chx_fig.add_trace(trace)

chx_fig.write_image('chx_diagram_countour_comparison.pdf', scale = 16)
