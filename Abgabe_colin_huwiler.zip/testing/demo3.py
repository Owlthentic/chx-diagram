from base.chx_diagram import CHXDiagram

# erstellt leeres Diagramm für 680 m.ü.M.
chx_diag = CHXDiagram(680)

# zeigt das Diagramm
chx_diag.show()

chx_diag.fig.write_image(
    'chx_diagram_custom_example.pdf',
    scale = 16)
