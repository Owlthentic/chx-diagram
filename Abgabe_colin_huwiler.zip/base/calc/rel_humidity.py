from base.calc.calc_base import CalcBase
from thermocalc.funkt_Luftstoffw import L_t_phi, L_x_phi
import numpy as np


class RelHumidity(CalcBase):
    TYPE = "rel_humidity"

    def create_line_steps(self, line_settings: dict) -> dict:
        calculation_settings = line_settings["calculation"]
        lines = calculation_settings["values"]

        return lines

    def calculate_lines_of_type(self, lines: dict, line_settings: dict):
        lines_line_type = {}
        lines_overflow = {}
        for line in lines:
            values, values_overflow = self.calculate_single_line(line, line_settings)
            lines_line_type[str(line)] = values
            lines_overflow[str(line)] = values_overflow
        return lines_line_type, lines_overflow

    def calculate_single_line(self, line: int, line_settings: dict):
        h_list_lines = []
        x_list_lines = []

        h_list_overflow = []
        x_list_overflow = []

        line_min = line_settings["line_range"][0]
        line_max = line_settings["line_range"][1]

        # check where to start
        if line_min == None or line_min < self.min_t:
            ts = self.min_t
        else:
            ts = line_min

        hs, xs = L_t_phi(ts, line/100, self.air_pressure)[0:2]
        if xs < self.min_x/1000:
            hs, xs = L_x_phi(self.min_x/1000, line/100, self.air_pressure)[0:2]

        h_list_lines.append(hs)
        x_list_lines.append(xs)

        # check where to stop
        if line_max == None or line_max > self.max_t:
            te = self.max_t
        else:
            te = line_max

        he, xe = L_t_phi(te, line/100, self.air_pressure)[0:2]
        if xe > self.max_x/1000:
            he, xe = L_x_phi(self.max_x/1000, line/100, self.air_pressure)[0:2]

        # create infill
        infill = np.linspace(start=xs, stop=xe, num=100)
        for xm in infill:
            hm, xm = L_x_phi(xm, line/100, self.air_pressure)[0:2]
            h_list_lines.append(hm)
            x_list_lines.append(xm)

        h_list_lines.append(he)
        x_list_lines.append(xe)

        h_list_overflow.append(he)
        x_list_overflow.append(xe)

        return ({"h": h_list_lines, "x": x_list_lines},
                {"h": h_list_overflow, "x": x_list_overflow})


if __name__ == '__main__':
    from pprint import pprint
    test = RelHumidity()
    pprint(test.values)
