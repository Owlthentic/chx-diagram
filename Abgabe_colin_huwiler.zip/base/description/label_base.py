from settings import Settings
import plotly.graph_objs as go

SETTINGS_PATH = "settings.json"


class LabelBase(object):
    TYPE = "temperature"

    def __init__(self, lines, fig: go.Figure):
        self._load_settings()
        self.annotations = []

        # load label settings
        self.font = self.settings_type["font"]
        self.arguments = self.settings_type["arguments"]
        self.rounding = self.settings_type["round"]
        self.offset = self.settings_type["offset"]

        self._create_labels(lines, fig)

    def _load_settings(self):
        # Gets Global Settings:
        self.settings_global = Settings().settings

        # Gets Settings for the specific line type
        self.settings_type = Settings().get("labels").get(self.TYPE)

    def _create_labels(self, lines: dict, fig: go.Figure):
        for line_type in self.settings_type["line_types"]:
            if line_type in lines[self.TYPE]["overflow_lines"].keys():
                lines_truncated = lines[self.TYPE]["overflow_lines"][line_type]
                for value in lines_truncated:
                    index = lines_truncated[value]
                    fig_line = fig.data[index]
                    self._create_label(fig_line, value)

    def _create_label(self, fig_line, value):
        # implemented in SubClass
        pass

    def check_bounds(self, x, y, bounds: str = "plot") -> bool:
        if bounds == "plot":
            dic_pos = "figure_settings"
        elif bounds == "calc":
            dic_pos = "calc_range"
        else:
            raise ValueError(f"\"{bounds}\" is not valid input. Allowed values are \"plot\", \"calc\"")

        x_range = self.settings_global[dic_pos]["x"]
        y_range = self.settings_global[dic_pos]["t"]
        x_min, x_max = x_range[0], x_range[-1]
        y_min, y_max = y_range[0], y_range[-1]
        if x_min <= x <= x_max:
            if y_min <= y <= y_max:
                return True
        return False


if __name__ == "__main__":
    from base.chx_diagram import CHXDiagram
    chx_diagram = CHXDiagram(650)

    label_enthalpy = LabelBase(chx_diagram.lines, chx_diagram.fig, "enthalpy")
    label_temperature = LabelBase(chx_diagram.lines, chx_diagram.fig, "temperature")
    label_rel_humidity = LabelBase(chx_diagram.lines, chx_diagram.fig, "rel_humidity")

    annotations = (label_enthalpy.annotations
                   + label_temperature.annotations
                   + label_rel_humidity.annotations)

    chx_diagram.fig.update_layout(annotations=annotations)

    chx_diagram.fig.update_layout(width=600,
                                  height=800,
                                  yaxis=dict(range=[-20.5, 80.5]),
                                  xaxis=dict(range=[-0.2, 20.1]))
    chx_diagram.fig.update_layout(showlegend=False)
    chx_diagram.fig.show(config={'editable': True, 'edits': {'annotationPosition': True}})




